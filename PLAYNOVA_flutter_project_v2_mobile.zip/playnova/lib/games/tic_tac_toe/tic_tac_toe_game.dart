import 'package:flutter/material.dart';
import '../_game_utils.dart';
class TicTacToeGame extends StatefulWidget { const TicTacToeGame({super.key}); @override State<TicTacToeGame> createState()=>_TttState(); }
class _TttState extends State<TicTacToeGame>{
 List<String> b=List.filled(9,''); bool x=true; bool over=false;
 void tap(int i){if(b[i].isNotEmpty||over)return; setState(()=>b[i]=x?'X':'O'); final w=winner(); if(w!=null){over=true; finishGame(context, w=='X'?100:50,w=='X');} else if(!b.contains('')){over=true; finishGame(context,50,false);} else x=!x;}
 String? winner(){for(final a in [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]){if(b[a[0]].isNotEmpty&&b[a[0]]==b[a[1]]&&b[a[1]]==b[a[2]])return b[a[0]];}return null;}
 void reset()=>setState(()=>{b=List.filled(9,''),x=true,over=false});
 @override Widget build(c)=>GameShell(title:'Tic-Tac-Toe',onRestart:reset,child:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Text('You are X',style:TextStyle(fontSize:20)),SizedBox(width:320,height:320,child:GridView.builder(itemCount:9,gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3),itemBuilder:(_,i)=>InkWell(onTap:()=>tap(i),child:Container(decoration:BoxDecoration(border:Border.all()),child:Center(child:Text(b[i],style:const TextStyle(fontSize:48,fontWeight:FontWeight.bold))))))),if(over)const Text('Game Over',style:TextStyle(fontSize:24))]))));
}
